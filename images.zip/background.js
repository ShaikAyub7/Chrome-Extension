let activeDomain = null;
let lastTimestamp = 0;
let intervalId = null;

function updateTabRuntime(domain, currentTime) {
  const today = new Date().toDateString();
  const elapsedTime = currentTime - lastTimestamp;

  // Log the current date and domain being tracked
  console.log("Saving runtime data for:", today, "Domain:", domain);

  chrome.storage.local.get([today], (data) => {
    let tabData = data[today] || {};

    if (elapsedTime > 0) {
      if (tabData[domain]) {
        tabData[domain].runtime += elapsedTime;
      } else {
        tabData[domain] = { runtime: elapsedTime };
      }

      // Save the updated tab data for today
      chrome.storage.local.set({ [today]: tabData }, () => {
        console.log("Data saved successfully for:", today);
      });
    }
  });
}

function startTrackingTime() {
  if (intervalId) clearInterval(intervalId);

  intervalId = setInterval(() => {
    if (activeDomain) {
      const currentTime = new Date().getTime();
      updateTabRuntime(activeDomain, currentTime);
      lastTimestamp = currentTime;
    }
  }, 1000);
}

chrome.tabs.onActivated.addListener((activeInfo) => {
  const currentTime = new Date().getTime();

  if (activeDomain !== null) {
    updateTabRuntime(activeDomain, currentTime);
  }

  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (tab && tab.url) {
      const domain = new URL(tab.url).hostname;
      activeDomain = domain;
      lastTimestamp = currentTime;

      startTrackingTime();
    }
  });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url) {
    const currentTime = new Date().getTime();
    const domain = new URL(tab.url).hostname;

    if (activeDomain !== null && domain !== activeDomain) {
      updateTabRuntime(activeDomain, currentTime);
    }

    activeDomain = domain;
    lastTimestamp = currentTime;
    startTrackingTime();
  }
});

chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
  const currentTime = new Date().getTime();

  if (activeDomain !== null) {
    updateTabRuntime(activeDomain, currentTime);
    activeDomain = null;
    clearInterval(intervalId);
  }
});
